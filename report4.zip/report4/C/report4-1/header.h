void main_allocate(int,int);
void func(int n,int ne,const int* cny,const float* mat,const float* u,float* r);
