void main_allocate(int,int,int,int);
void cg(int,int,int,int*,int*,float*,float*,float*,float*,float*);
void cal_amat(int n,int ne,int kd,const int* cny,const int* num,const float* coor,const float* younglst,const float* u,float* r);