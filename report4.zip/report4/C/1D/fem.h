void main_allocate(int,int,int);
void cal_amat(int n,int ne,int kd,const int* cny,const int* num,const float* coor,const float* younglst,const float* u,float* r);